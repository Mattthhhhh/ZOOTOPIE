import pygame
import sys
import math
import os
import subprocess

#Yanis hakimi
#Yanis Zekiri
#Matthys JACQUIN-BALITOUT
# Nadir

# Initialisation de Pygame
pygame.init()

# Constantes
WIDTH, HEIGHT = 800, 600
FPS = 60
WHITE = (255, 255, 255)
BLACK = (15, 15, 25)
GREEN = (80, 200, 120)
RED = (220, 80, 80)
LIGHT_GREEN = (120, 240, 160)
LIGHT_RED = (255, 120, 120)
SHADOW = (10, 10, 10)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Menu Start")
clock = pygame.time.Clock()

# Image de fond
image_path = "ZOO2.jpg"
if os.path.exists(image_path):
    background = pygame.image.load(image_path).convert()
    background = pygame.transform.scale(background, (WIDTH, HEIGHT))

overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
overlay.fill((0, 0, 0, 110))

# Polices
title_font = pygame.font.SysFont('Arial', 70, bold=True)
button_font = pygame.font.SysFont('Arial', 40)

def draw_text(text, font, color, x, y, shadow=False):
    if shadow:
        shadow_surface = font.render(text, True, SHADOW)
        shadow_rect = shadow_surface.get_rect(center=(x+3, y+3))
        screen.blit(shadow_surface, shadow_rect)

    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(x, y))
    screen.blit(text_surface, text_rect)

def draw_button(rect, base_color, hover_color, text):
    mouse_pos = pygame.mouse.get_pos()
    is_hovered = rect.collidepoint(mouse_pos)

    pygame.draw.rect(screen, SHADOW, rect.move(5, 5), border_radius=12)
    color = hover_color if is_hovered else base_color
    pygame.draw.rect(screen, color, rect, border_radius=12)

    draw_text(text, button_font, BLACK, rect.centerx, rect.centery)
    return is_hovered

def start_game():
    print("Lancement de main.py...")
    subprocess.Popen([sys.executable, r"C:\Users\HK\Desktop\ZOO\main.py"])
    pygame.quit()
    sys.exit()

def main_menu():
    pulse = 0
    zoom = 1.0

    while True:
        clock.tick(FPS)
        pulse += 0.03
        zoom += 0.0003
        if zoom > 1.01:
            zoom = 1.0

        bg_width = int(WIDTH * zoom)
        bg_height = int(HEIGHT * zoom)
        scaled_bg = pygame.transform.scale(background, (bg_width, bg_height))
        screen.blit(scaled_bg, ((WIDTH - bg_width) // 2, (HEIGHT - bg_height) // 2))

        screen.blit(overlay, (0, 0))

        title_y = HEIGHT // 4 + int(8 * math.sin(pulse))
        draw_text("MENU PRINCIPAL", title_font, WHITE, WIDTH // 2, title_y, shadow=True)

        play_button = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 - 40, 240, 60)
        quit_button = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 + 60, 240, 60)

        play_hover = draw_button(play_button, GREEN, LIGHT_GREEN, "JOUER")
        quit_hover = draw_button(quit_button, RED, LIGHT_RED, "QUITTER")

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_hover:
                    start_game()
                if quit_hover:
                    pygame.quit()
                    sys.exit()

        pygame.display.flip()

main_menu()
